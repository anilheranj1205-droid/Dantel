export const CLINIC_NAME = "Sri Hari Har Dental Clinic & Prosthetics";
export const CLINIC_SHORT_NAME = "Sri Hari Har Dental";
export const CLINIC_PHONE = "+91 98170 71902";
export const CLINIC_PHONE_LINK = "tel:+919817071902";
export const CLINIC_WHATSAPP = "https://wa.me/919817071902";
export const CLINIC_ADDRESS = "Khuda Lahora, Chandigarh, India";
export const CLINIC_GOOGLE_MAPS = "https://www.google.com/maps/place/Khuda+Lahora,+Chandigarh";
export const CLINIC_GOOGLE_MAPS_EMBED = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13720.!2d76.72!3d30.73!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sKhuda+Lahora+Chandigarh!5e0!3m2!1sen!2sin!4v1";
export const CLINIC_RATING = "4.9";
export const CLINIC_REVIEWS = "76+";
export const CLINIC_EXPERIENCE = "15+";
export const CLINIC_PATIENTS = "10,000+";

export const WORKING_HOURS = {
  weekday: { days: "Monday - Saturday", hours: "8:00 AM - 8:00 PM" },
  weekend: { days: "Sunday", hours: "9:00 AM - 8:30 PM" },
};

export const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/gallery", label: "Gallery" },
  { href: "/reviews", label: "Reviews" },
  { href: "/contact", label: "Contact" },
];

export const SERVICES = [
  {
    title: "Root Canal",
    description: "Painless root canal treatment to save infected teeth and relieve pain using advanced techniques.",
    icon: "Zap",
  },
  {
    title: "Dental Implants",
    description: "Permanent tooth replacement with titanium implants that look and feel like natural teeth.",
    icon: "CircleDot",
  },
  {
    title: "Teeth Cleaning",
    description: "Professional scaling and polishing to remove plaque, tartar, and stains for healthier gums.",
    icon: "Sparkles",
  },
  {
    title: "Teeth Whitening",
    description: "Safe and effective whitening treatments to brighten your smile by several shades.",
    icon: "Sun",
  },
  {
    title: "Tooth Extraction",
    description: "Gentle and safe removal of damaged or problematic teeth with minimal discomfort.",
    icon: "Minus",
  },
  {
    title: "Crowns & Bridges",
    description: "Custom-fitted crowns and bridges to restore damaged teeth and fill gaps in your smile.",
    icon: "Crown",
  },
  {
    title: "Dentures",
    description: "Comfortable and natural-looking full and partial dentures for a complete smile.",
    icon: "Smile",
  },
  {
    title: "Laser Dentistry",
    description: "Minimally invasive laser treatments for gum therapy, cavity removal, and tissue reshaping.",
    icon: "Crosshair",
  },
  {
    title: "Cosmetic Dentistry",
    description: "Smile makeovers including veneers, bonding, and reshaping for a perfect appearance.",
    icon: "Star",
  },
  {
    title: "Fillings",
    description: "Tooth-colored composite fillings to treat cavities while maintaining a natural look.",
    icon: "Shield",
  },
  {
    title: "Oral Surgery",
    description: "Surgical procedures including wisdom tooth removal, jaw corrections, and biopsies.",
    icon: "Scissors",
  },
  {
    title: "Pediatric Dentistry",
    description: "Gentle dental care for children in a friendly environment to build healthy habits early.",
    icon: "Heart",
  },
];

export const REVIEWS_DATA = [
  {
    name: "Rajesh Kumar",
    rating: 5,
    text: "Excellent dental care! Dr. was very gentle and explained every step of my root canal. Highly recommend this clinic.",
    date: "2 months ago",
  },
  {
    name: "Priya Sharma",
    rating: 5,
    text: "Best dental clinic in Chandigarh. Got my teeth whitening done here and the results are amazing. Very professional staff.",
    date: "1 month ago",
  },
  {
    name: "Amit Singh",
    rating: 5,
    text: "My family has been visiting this clinic for years. The doctor is highly skilled and the clinic is very clean and modern.",
    date: "3 weeks ago",
  },
  {
    name: "Sunita Verma",
    rating: 5,
    text: "Got dental implants done here. The procedure was painless and the results are fantastic. Thank you, Doctor!",
    date: "1 month ago",
  },
  {
    name: "Vikram Patel",
    rating: 5,
    text: "Very affordable and quality dental treatment. The staff is courteous and the waiting area is comfortable.",
    date: "2 weeks ago",
  },
  {
    name: "Meena Gupta",
    rating: 4,
    text: "Good experience overall. My dental cleaning was thorough and the doctor gave helpful tips for oral care at home.",
    date: "3 months ago",
  },
];

export const GALLERY_IMAGES = [
  { src: "/images/clinic-exterior.jpg", alt: "Clinic Exterior", category: "Clinic" },
  { src: "/images/treatment-room.jpg", alt: "Treatment Room", category: "Treatment Room" },
  { src: "/images/waiting-area.jpg", alt: "Waiting Area", category: "Waiting Area" },
  { src: "/images/dental-equipment.jpg", alt: "Dental Equipment", category: "Equipment" },
  { src: "/images/reception.jpg", alt: "Reception Area", category: "Clinic" },
  { src: "/images/sterilization.jpg", alt: "Sterilization Room", category: "Equipment" },
];

export const TREATMENTS = [
  "Root Canal",
  "Dental Implants",
  "Teeth Cleaning",
  "Teeth Whitening",
  "Tooth Extraction",
  "Crowns & Bridges",
  "Dentures",
  "Laser Dentistry",
  "Cosmetic Dentistry",
  "Fillings",
  "Oral Surgery",
  "General Checkup",
];
