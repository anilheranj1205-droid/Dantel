import Link from "next/link";
import { Phone, MapPin, Clock, Mail } from "lucide-react";
import {
  CLINIC_NAME,
  CLINIC_PHONE,
  CLINIC_PHONE_LINK,
  CLINIC_ADDRESS,
  WORKING_HOURS,
  NAV_LINKS,
} from "@/lib/constants";

export default function Footer() {
  return (
    <footer className="bg-text text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-white text-sm font-bold">
                SH
              </div>
              <span className="text-lg font-semibold">{CLINIC_NAME}</span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed">
              Providing quality dental care with a gentle touch. Your smile is our priority.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/60 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/appointment"
                  className="text-sm text-white/60 hover:text-primary transition-colors"
                >
                  Appointment
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <a href={CLINIC_PHONE_LINK} className="text-sm text-white/60 hover:text-primary transition-colors">
                  {CLINIC_PHONE}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-white/60">info@sriharihar.dental</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-white/60">{CLINIC_ADDRESS}</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Working Hours</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm text-white/80 font-medium">{WORKING_HOURS.weekday.days}</p>
                  <p className="text-sm text-white/60">{WORKING_HOURS.weekday.hours}</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm text-white/80 font-medium">{WORKING_HOURS.weekend.days}</p>
                  <p className="text-sm text-white/60">{WORKING_HOURS.weekend.hours}</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-white/40">
            &copy; {new Date().getFullYear()} {CLINIC_NAME}. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link href="/privacy-policy" className="text-sm text-white/40 hover:text-primary transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-sm text-white/40 hover:text-primary transition-colors">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
