interface SectionHeadingProps {
  label?: string;
  title: string;
  description?: string;
  center?: boolean;
}

export default function SectionHeading({ label, title, description, center = true }: SectionHeadingProps) {
  return (
    <div className={`mb-12 ${center ? "text-center" : ""}`}>
      {label && (
        <span className="inline-block text-xs font-semibold uppercase tracking-wider text-primary mb-2">
          {label}
        </span>
      )}
      <h2 className="text-3xl sm:text-4xl font-bold text-text">{title}</h2>
      {description && (
        <p className="mt-4 max-w-2xl text-text/60 text-lg leading-relaxed mx-auto">
          {description}
        </p>
      )}
    </div>
  );
}
