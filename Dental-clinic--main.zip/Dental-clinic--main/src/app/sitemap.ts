import type { MetadataRoute } from "next";

const BASE_URL = "https://sriharihar.dental";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = [
    "",
    "/about",
    "/services",
    "/appointment",
    "/reviews",
    "/gallery",
    "/contact",
    "/privacy-policy",
    "/terms",
  ];

  return routes.map((route) => ({
    url: `${BASE_URL}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" ? "weekly" : "monthly",
    priority: route === "" ? 1 : route === "/appointment" ? 0.9 : 0.7,
  }));
}
