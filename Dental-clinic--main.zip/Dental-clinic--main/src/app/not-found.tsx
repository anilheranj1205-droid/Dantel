import Link from "next/link";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <section className="py-24 sm:py-32 bg-white">
      <div className="mx-auto max-w-lg px-4 text-center">
        <p className="text-6xl font-bold text-primary">404</p>
        <h1 className="mt-4 text-3xl font-bold text-text">Page Not Found</h1>
        <p className="mt-4 text-text/60 leading-relaxed">
          Sorry, we could not find the page you are looking for. It may have been moved or
          does not exist.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 text-base font-medium text-white bg-primary rounded-xl hover:bg-primary-dark transition-colors"
          >
            <Home className="h-5 w-5" />
            Go Home
          </Link>
          <Link
            href="/contact"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 text-base font-medium text-primary border border-primary/20 rounded-xl hover:bg-primary/5 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            Contact Us
          </Link>
        </div>
      </div>
    </section>
  );
}
