import Link from "next/link";
import {
  Phone,
  Calendar,
  Star,
  Users,
  Award,
  Clock,
  ChevronRight,
  Shield,
  Heart,
  Sparkles,
} from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import {
  CLINIC_NAME,
  CLINIC_PHONE_LINK,
  CLINIC_WHATSAPP,
  CLINIC_RATING,
  CLINIC_REVIEWS,
  CLINIC_EXPERIENCE,
  CLINIC_PATIENTS,
  SERVICES,
} from "@/lib/constants";

const ICON_MAP: Record<string, React.ReactNode> = {
  Zap: <Sparkles className="h-6 w-6" />,
  CircleDot: <Shield className="h-6 w-6" />,
  Sparkles: <Sparkles className="h-6 w-6" />,
  Sun: <Star className="h-6 w-6" />,
  Minus: <Heart className="h-6 w-6" />,
  Crown: <Award className="h-6 w-6" />,
};

const STATS = [
  { icon: <Star className="h-6 w-6" />, value: CLINIC_RATING, label: "Google Rating" },
  { icon: <Users className="h-6 w-6" />, value: CLINIC_PATIENTS, label: "Happy Patients" },
  { icon: <Award className="h-6 w-6" />, value: CLINIC_EXPERIENCE, label: "Years Experience" },
  { icon: <Clock className="h-6 w-6" />, value: CLINIC_REVIEWS, label: "Google Reviews" },
];

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-full text-primary text-sm font-medium mb-6">
                <Star className="h-4 w-4 fill-primary" />
                <span>Rated {CLINIC_RATING}/5 on Google</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-text leading-tight">
                Your Smile,{" "}
                <span className="text-primary">Our Priority</span>
              </h1>
              <p className="mt-6 text-lg text-text/60 max-w-lg leading-relaxed">
                Welcome to {CLINIC_NAME}. We provide gentle, professional dental
                care for your entire family in Chandigarh.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link
                  href="/appointment"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-white bg-primary rounded-xl hover:bg-primary-dark transition-colors"
                >
                  <Calendar className="h-5 w-5" />
                  Book Appointment
                </Link>
                <a
                  href={CLINIC_PHONE_LINK}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-primary border border-primary/20 rounded-xl hover:bg-primary/5 transition-colors"
                >
                  <Phone className="h-5 w-5" />
                  Call Now
                </a>
                <a
                  href={CLINIC_WHATSAPP}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-[#25D366] border border-[#25D366]/20 rounded-xl hover:bg-[#25D366]/5 transition-colors"
                >
                  WhatsApp
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl bg-secondary flex items-center justify-center overflow-hidden">
                <div className="text-center p-8">
                  <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 mb-4">
                    <Heart className="h-10 w-10 text-primary" />
                  </div>
                  <p className="text-xl font-semibold text-text">Caring Dental Team</p>
                  <p className="text-text/60 mt-2">Professional & Gentle Care</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-secondary py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {STATS.map((stat) => (
              <div
                key={stat.label}
                className="flex flex-col items-center text-center p-6 bg-white rounded-xl"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-3">
                  {stat.icon}
                </div>
                <span className="text-2xl sm:text-3xl font-bold text-text">{stat.value}</span>
                <span className="text-sm text-text/50 mt-1">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Our Services"
            title="Complete Dental Care"
            description="From routine checkups to advanced procedures, we offer comprehensive dental services for every need."
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.slice(0, 6).map((service) => (
              <div
                key={service.title}
                className="p-6 rounded-xl border border-border hover:border-primary/30 hover:shadow-sm transition-all"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                  {ICON_MAP[service.icon] || <Sparkles className="h-6 w-6" />}
                </div>
                <h3 className="text-lg font-semibold text-text">{service.title}</h3>
                <p className="mt-2 text-sm text-text/60 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link
              href="/services"
              className="inline-flex items-center gap-1 text-primary font-medium hover:text-primary-dark transition-colors"
            >
              View All Services
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            Ready for a Healthier Smile?
          </h2>
          <p className="mt-4 text-lg text-white/80 max-w-xl mx-auto">
            Book your appointment in under 60 seconds. Walk-ins also welcome.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
            <Link
              href="/appointment"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-primary bg-white rounded-xl hover:bg-white/90 transition-colors"
            >
              <Calendar className="h-5 w-5" />
              Book Appointment
            </Link>
            <a
              href={CLINIC_PHONE_LINK}
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-white border border-white/30 rounded-xl hover:bg-white/10 transition-colors"
            >
              <Phone className="h-5 w-5" />
              Call +91 98170 71902
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
