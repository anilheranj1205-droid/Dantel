import type { Metadata } from "next";
import { Star, ExternalLink } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { CLINIC_RATING, CLINIC_REVIEWS, REVIEWS_DATA, CLINIC_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Reviews",
  description: `Read ${CLINIC_REVIEWS} patient reviews for ${CLINIC_NAME}. Rated ${CLINIC_RATING}/5 on Google.`,
};

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < rating ? "fill-amber-400 text-amber-400" : "text-border"
          }`}
        />
      ))}
    </div>
  );
}

export default function ReviewsPage() {
  return (
    <>
      <section className="bg-secondary py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Patient Reviews"
            title="What Our Patients Say"
            description="We are proud of the trust our patients place in us."
          />
          {/* Rating overview */}
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-3">
              <span className="text-5xl font-bold text-text">{CLINIC_RATING}</span>
              <div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-text/60 mt-1">{CLINIC_REVIEWS} reviews on Google</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {REVIEWS_DATA.map((review) => (
              <div
                key={review.name}
                className="p-6 rounded-xl border border-border"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary text-sm font-bold">
                    {review.name[0]}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-text">{review.name}</p>
                    <p className="text-xs text-text/40">{review.date}</p>
                  </div>
                </div>
                <StarRating rating={review.rating} />
                <p className="mt-3 text-sm text-text/60 leading-relaxed">{review.text}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <a
              href="https://www.google.com/maps/place/Sri+Hari+Har+Dental+Clinic"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 text-base font-medium text-primary border border-primary/20 rounded-xl hover:bg-primary/5 transition-colors"
            >
              View All Google Reviews
              <ExternalLink className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
