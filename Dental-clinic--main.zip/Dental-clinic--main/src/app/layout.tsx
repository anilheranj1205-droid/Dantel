import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import { CLINIC_NAME } from "@/lib/constants";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: `${CLINIC_NAME} | Best Dentist in Chandigarh`,
    template: `%s | ${CLINIC_NAME}`,
  },
  description:
    "Sri Hari Har Dental Clinic & Prosthetics in Khuda Lahora, Chandigarh. Rated 4.9/5 with 76+ reviews. Root canal, implants, whitening & more. Book appointment now.",
  keywords: [
    "dentist chandigarh",
    "dental clinic chandigarh",
    "root canal chandigarh",
    "dental implants chandigarh",
    "teeth whitening chandigarh",
    "best dentist khuda lahora",
    "sri hari har dental",
  ],
  openGraph: {
    title: `${CLINIC_NAME} | Best Dentist in Chandigarh`,
    description:
      "Rated 4.9/5 with 76+ reviews. Root canal, implants, whitening & more. Book appointment now.",
    type: "website",
    locale: "en_IN",
    siteName: CLINIC_NAME,
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  );
}
