import type { Metadata } from "next";
import { CLINIC_NAME, CLINIC_PHONE } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `Privacy Policy for ${CLINIC_NAME}. Learn how we collect, use, and protect your personal information.`,
};

export default function PrivacyPolicyPage() {
  return (
    <section className="py-16 sm:py-24 bg-white">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-text mb-8">Privacy Policy</h1>
        <div className="prose prose-gray max-w-none space-y-6 text-text/70 leading-relaxed">
          <p>
            <strong className="text-text">Effective Date:</strong> January 1, 2024
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">1. Information We Collect</h2>
          <p>
            When you book an appointment or contact us, we may collect your name, phone number,
            and treatment preferences. This information is used solely to provide dental services
            and communicate with you about your appointments.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">2. How We Use Your Information</h2>
          <p>We use your personal information to:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Schedule and manage your dental appointments</li>
            <li>Communicate with you about your treatment</li>
            <li>Send appointment reminders</li>
            <li>Improve our services</li>
          </ul>

          <h2 className="text-xl font-semibold text-text mt-8">3. Data Protection</h2>
          <p>
            We implement appropriate security measures to protect your personal information.
            Your data is not shared with third parties except as required by law or for the
            purpose of providing dental services.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">4. Your Rights</h2>
          <p>
            You have the right to access, correct, or delete your personal information.
            Contact us at {CLINIC_PHONE} to exercise these rights.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">5. Contact</h2>
          <p>
            For questions about this privacy policy, contact {CLINIC_NAME} at{" "}
            {CLINIC_PHONE}.
          </p>
        </div>
      </div>
    </section>
  );
}
