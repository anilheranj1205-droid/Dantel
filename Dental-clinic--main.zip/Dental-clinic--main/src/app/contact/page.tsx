import type { Metadata } from "next";
import { Phone, MapPin, Clock, Navigation, MessageCircle } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import {
  CLINIC_NAME,
  CLINIC_PHONE,
  CLINIC_PHONE_LINK,
  CLINIC_WHATSAPP,
  CLINIC_ADDRESS,
  CLINIC_GOOGLE_MAPS,
  WORKING_HOURS,
} from "@/lib/constants";

export const metadata: Metadata = {
  title: "Contact",
  description: `Contact ${CLINIC_NAME} at ${CLINIC_PHONE}. Located in ${CLINIC_ADDRESS}. Open 7 days a week.`,
};

export default function ContactPage() {
  return (
    <>
      <section className="bg-secondary py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Contact Us"
            title="Get in Touch"
            description="We are here to help. Reach out to us through any of the channels below."
          />
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-text">Phone</h3>
                  <a
                    href={CLINIC_PHONE_LINK}
                    className="text-text/60 hover:text-primary transition-colors"
                  >
                    {CLINIC_PHONE}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-text">WhatsApp</h3>
                  <a
                    href={CLINIC_WHATSAPP}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-text/60 hover:text-primary transition-colors"
                  >
                    Chat with us on WhatsApp
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <MapPin className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-text">Address</h3>
                  <p className="text-text/60">{CLINIC_ADDRESS}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-text">Working Hours</h3>
                  <div className="mt-1 space-y-1">
                    <p className="text-text/60">
                      <span className="font-medium text-text/80">{WORKING_HOURS.weekday.days}:</span>{" "}
                      {WORKING_HOURS.weekday.hours}
                    </p>
                    <p className="text-text/60">
                      <span className="font-medium text-text/80">{WORKING_HOURS.weekend.days}:</span>{" "}
                      {WORKING_HOURS.weekend.hours}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <a
                  href={CLINIC_PHONE_LINK}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-white bg-primary rounded-xl hover:bg-primary-dark transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  Call Now
                </a>
                <a
                  href={CLINIC_GOOGLE_MAPS}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-primary border border-primary/20 rounded-xl hover:bg-primary/5 transition-colors"
                >
                  <Navigation className="h-4 w-4" />
                  Get Directions
                </a>
              </div>
            </div>

            {/* Map */}
            <div className="rounded-xl overflow-hidden border border-border bg-secondary aspect-[4/3] lg:aspect-auto flex items-center justify-center">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13720.2!2d76.72!3d30.73!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390f9586d5f4f4f%3A0x0!2sKhuda%20Lahora%2C%20Chandigarh!5e0!3m2!1sen!2sin!4v1"
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: 350 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Clinic location on Google Maps"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
