import type { Metadata } from "next";
import { CLINIC_NAME, CLINIC_PHONE } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: `Terms and conditions for ${CLINIC_NAME}. Read our terms of service and policies.`,
};

export default function TermsPage() {
  return (
    <section className="py-16 sm:py-24 bg-white">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-text mb-8">Terms & Conditions</h1>
        <div className="prose prose-gray max-w-none space-y-6 text-text/70 leading-relaxed">
          <p>
            <strong className="text-text">Effective Date:</strong> January 1, 2024
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">1. Appointments</h2>
          <p>
            Appointment bookings made through our website are requests and will be confirmed
            by our staff. We recommend arriving 10 minutes before your scheduled appointment.
            Please inform us at least 2 hours in advance if you need to cancel or reschedule.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">2. Treatment</h2>
          <p>
            All dental treatments are performed by qualified professionals. Treatment plans
            are discussed with patients before any procedure begins. Costs and alternatives
            will be explained clearly.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">3. Payment</h2>
          <p>
            Payment is due at the time of service unless prior arrangements have been made.
            We accept cash and digital payment methods.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">4. Liability</h2>
          <p>
            While we strive for the best outcomes, dental procedures carry inherent risks.
            All risks and potential complications will be discussed before treatment.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">5. Website</h2>
          <p>
            The content on this website is for informational purposes only and does not
            constitute medical advice. Always consult with our dental professionals for
            personalized recommendations.
          </p>

          <h2 className="text-xl font-semibold text-text mt-8">6. Contact</h2>
          <p>
            For questions about these terms, contact {CLINIC_NAME} at {CLINIC_PHONE}.
          </p>
        </div>
      </div>
    </section>
  );
}
