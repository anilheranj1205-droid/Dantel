import type { Metadata } from "next";
import { Heart, Target, Eye, CheckCircle, Award, Users, Clock, Shield } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { CLINIC_NAME, CLINIC_EXPERIENCE } from "@/lib/constants";

export const metadata: Metadata = {
  title: "About Us",
  description: `Learn about ${CLINIC_NAME}, our mission, vision, and the experienced dental team serving Chandigarh for ${CLINIC_EXPERIENCE} years.`,
};

const WHY_CHOOSE = [
  { icon: <Award className="h-6 w-6" />, title: "Experienced Doctor", description: "Over 15 years of clinical expertise in all dental specialties." },
  { icon: <Shield className="h-6 w-6" />, title: "Advanced Technology", description: "State-of-the-art equipment for precise diagnostics and treatment." },
  { icon: <Heart className="h-6 w-6" />, title: "Gentle Care", description: "Painless procedures with a patient-first approach for all ages." },
  { icon: <Clock className="h-6 w-6" />, title: "Convenient Hours", description: "Open 7 days a week with flexible morning and evening slots." },
  { icon: <Users className="h-6 w-6" />, title: "Family Friendly", description: "Comfortable environment for children, adults, and seniors alike." },
  { icon: <CheckCircle className="h-6 w-6" />, title: "Affordable Prices", description: "Quality dental care at fair and transparent pricing." },
];

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-secondary py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="About Us"
            title="Your Trusted Dental Partner in Chandigarh"
            description={`${CLINIC_NAME} has been providing exceptional dental care to the Chandigarh community for over ${CLINIC_EXPERIENCE} years.`}
          />
        </div>
      </section>

      {/* Story */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-text mb-6">Our Story</h2>
              <div className="space-y-4 text-text/60 leading-relaxed">
                <p>
                  Founded with a passion for oral health, {CLINIC_NAME} began as a small practice
                  in Khuda Lahora, Chandigarh. Over the years, we have grown into a trusted name
                  for comprehensive dental care in the region.
                </p>
                <p>
                  Our clinic combines modern technology with compassionate care to ensure every
                  patient leaves with a healthy, confident smile. From routine cleanings to
                  complex prosthetic work, we handle every case with precision and dedication.
                </p>
                <p>
                  With over 10,000 happy patients and a 4.9-star Google rating, we take pride
                  in the trust our community has placed in us.
                </p>
              </div>
            </div>
            <div className="aspect-[4/3] rounded-2xl bg-secondary flex items-center justify-center">
              <div className="text-center p-8">
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 mb-4">
                  <Heart className="h-10 w-10 text-primary" />
                </div>
                <p className="text-xl font-semibold text-text">{CLINIC_EXPERIENCE}+ Years</p>
                <p className="text-text/60 mt-2">of Trusted Dental Care</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-secondary">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                <Target className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-text mb-3">Our Mission</h3>
              <p className="text-text/60 leading-relaxed">
                To provide accessible, affordable, and high-quality dental care to every patient.
                We aim to make dental visits comfortable and stress-free while delivering
                outstanding clinical results.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                <Eye className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-text mb-3">Our Vision</h3>
              <p className="text-text/60 leading-relaxed">
                To be the most trusted dental clinic in Chandigarh, known for clinical excellence,
                patient satisfaction, and community health impact. We envision a future where
                everyone has access to quality dental care.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Doctor Profile */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Meet The Doctor"
            title="Expert Care You Can Trust"
          />
          <div className="max-w-3xl mx-auto text-center">
            <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-primary/10 mb-6">
              <Users className="h-12 w-12 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-text">Dr. Dental Specialist</h3>
            <p className="text-primary font-medium mt-1">BDS, MDS - Prosthodontics</p>
            <p className="mt-4 text-text/60 leading-relaxed max-w-xl mx-auto">
              With over {CLINIC_EXPERIENCE} years of experience in general and prosthetic dentistry,
              our doctor is committed to providing the best possible care. Specializing in dental
              implants, crowns, bridges, and complete denture rehabilitation, every treatment is
              tailored to meet individual patient needs.
            </p>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 sm:py-24 bg-secondary">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Why Choose Us"
            title="What Sets Us Apart"
            description="We combine expertise, technology, and compassion to deliver a dental experience you'll love."
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {WHY_CHOOSE.map((item) => (
              <div
                key={item.title}
                className="bg-white p-6 rounded-xl"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                  {item.icon}
                </div>
                <h3 className="text-lg font-semibold text-text">{item.title}</h3>
                <p className="mt-2 text-sm text-text/60 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
