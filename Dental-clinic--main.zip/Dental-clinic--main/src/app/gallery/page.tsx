import type { Metadata } from "next";
import { Camera } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { CLINIC_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Gallery",
  description: `View our modern clinic, equipment, and treatment rooms at ${CLINIC_NAME} in Chandigarh.`,
};

const GALLERY_ITEMS = [
  { title: "Clinic Exterior", description: "Our welcoming clinic in Khuda Lahora", color: "bg-primary/10" },
  { title: "Treatment Room", description: "Modern and fully equipped treatment area", color: "bg-blue-50" },
  { title: "Waiting Area", description: "Comfortable waiting lounge for patients", color: "bg-green-50" },
  { title: "Dental Equipment", description: "State-of-the-art dental technology", color: "bg-amber-50" },
  { title: "Reception", description: "Friendly reception desk", color: "bg-purple-50" },
  { title: "Sterilization Room", description: "Strict hygiene and sterilization protocols", color: "bg-rose-50" },
];

export default function GalleryPage() {
  return (
    <>
      <section className="bg-secondary py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Gallery"
            title="Take a Tour of Our Clinic"
            description="See our modern facilities, advanced equipment, and comfortable environment."
          />
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {GALLERY_ITEMS.map((item) => (
              <div
                key={item.title}
                className="group rounded-xl overflow-hidden border border-border"
              >
                <div className={`aspect-[4/3] ${item.color} flex items-center justify-center`}>
                  <div className="text-center">
                    <Camera className="h-10 w-10 text-text/20 mx-auto mb-2" />
                    <p className="text-sm text-text/40">Photo coming soon</p>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-base font-semibold text-text">{item.title}</h3>
                  <p className="text-sm text-text/60 mt-1">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
