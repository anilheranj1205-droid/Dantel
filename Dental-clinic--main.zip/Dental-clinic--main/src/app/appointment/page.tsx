"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod/v4";
import { CheckCircle, Calendar, User, Stethoscope, ChevronRight, ChevronLeft } from "lucide-react";
import { TREATMENTS, CLINIC_WHATSAPP, CLINIC_NAME } from "@/lib/constants";

const appointmentSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian phone number"),
  treatment: z.string().min(1, "Please select a treatment"),
  date: z.string().min(1, "Please select a date"),
  time: z.string().min(1, "Please select a time slot"),
});

type AppointmentForm = z.infer<typeof appointmentSchema>;

const TIME_SLOTS = [
  "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM",
  "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM",
  "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM",
];

const STEPS = [
  { label: "Personal Info", icon: <User className="h-5 w-5" /> },
  { label: "Treatment", icon: <Stethoscope className="h-5 w-5" /> },
  { label: "Confirm", icon: <CheckCircle className="h-5 w-5" /> },
];

export default function AppointmentPage() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const {
    register,
    handleSubmit,
    trigger,
    getValues,
    formState: { errors },
  } = useForm<AppointmentForm>({
    resolver: zodResolver(appointmentSchema),
    mode: "onBlur",
  });

  const nextStep = async () => {
    let valid = false;
    if (step === 0) {
      valid = await trigger(["name", "phone"]);
    } else if (step === 1) {
      valid = await trigger(["treatment", "date", "time"]);
    }
    if (valid) setStep((s) => s + 1);
  };

  const prevStep = () => setStep((s) => s - 1);

  const onSubmit = () => {
    setSubmitted(true);
  };

  const today = new Date().toISOString().split("T")[0];

  if (submitted) {
    const values = getValues();
    const whatsappMsg = encodeURIComponent(
      `Hi, I'd like to book an appointment.\n\nName: ${values.name}\nPhone: ${values.phone}\nTreatment: ${values.treatment}\nDate: ${values.date}\nTime: ${values.time}`
    );
    return (
      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-lg px-4 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/10 mb-6">
            <CheckCircle className="h-8 w-8 text-success" />
          </div>
          <h1 className="text-3xl font-bold text-text">Appointment Requested!</h1>
          <p className="mt-4 text-text/60 leading-relaxed">
            Thank you, {values.name}! Your appointment request for {values.treatment} on{" "}
            {values.date} at {values.time} has been received.
          </p>
          <p className="mt-2 text-text/60">
            We will confirm your appointment shortly. You can also reach us on WhatsApp.
          </p>
          <a
            href={`${CLINIC_WHATSAPP}?text=${whatsappMsg}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-white bg-[#25D366] rounded-xl hover:bg-[#20BD5C] transition-colors"
          >
            Confirm on WhatsApp
          </a>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="bg-secondary py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl sm:text-4xl font-bold text-text">Book an Appointment</h1>
          <p className="mt-3 text-text/60">
            Schedule your visit at {CLINIC_NAME} in under 60 seconds.
          </p>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-white">
        <div className="mx-auto max-w-xl px-4">
          {/* Steps indicator */}
          <div className="flex items-center justify-center gap-2 mb-10">
            {STEPS.map((s, i) => (
              <div key={s.label} className="flex items-center gap-2">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-medium transition-colors ${
                    i <= step
                      ? "bg-primary text-white"
                      : "bg-border text-text/40"
                  }`}
                >
                  {i < step ? <CheckCircle className="h-5 w-5" /> : s.icon}
                </div>
                <span
                  className={`text-sm font-medium hidden sm:block ${
                    i <= step ? "text-primary" : "text-text/40"
                  }`}
                >
                  {s.label}
                </span>
                {i < STEPS.length - 1 && (
                  <div className={`w-8 sm:w-12 h-0.5 ${i < step ? "bg-primary" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Step 1: Personal Info */}
            {step === 0 && (
              <div className="space-y-5">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-text mb-1.5">
                    Full Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    placeholder="Enter your name"
                    {...register("name")}
                    className="w-full px-4 py-3 rounded-xl border border-border text-text placeholder:text-text/30 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                  />
                  {errors.name && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.name.message}</p>
                  )}
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-text mb-1.5">
                    Phone Number
                  </label>
                  <input
                    id="phone"
                    type="tel"
                    placeholder="10-digit mobile number"
                    {...register("phone")}
                    className="w-full px-4 py-3 rounded-xl border border-border text-text placeholder:text-text/30 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                  />
                  {errors.phone && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.phone.message}</p>
                  )}
                </div>
              </div>
            )}

            {/* Step 2: Treatment Details */}
            {step === 1 && (
              <div className="space-y-5">
                <div>
                  <label htmlFor="treatment" className="block text-sm font-medium text-text mb-1.5">
                    Treatment
                  </label>
                  <select
                    id="treatment"
                    {...register("treatment")}
                    className="w-full px-4 py-3 rounded-xl border border-border text-text focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                  >
                    <option value="">Select a treatment</option>
                    {TREATMENTS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  {errors.treatment && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.treatment.message}</p>
                  )}
                </div>
                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-text mb-1.5">
                    Preferred Date
                  </label>
                  <input
                    id="date"
                    type="date"
                    min={today}
                    {...register("date")}
                    className="w-full px-4 py-3 rounded-xl border border-border text-text focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                  />
                  {errors.date && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.date.message}</p>
                  )}
                </div>
                <div>
                  <label htmlFor="time" className="block text-sm font-medium text-text mb-1.5">
                    Preferred Time
                  </label>
                  <select
                    id="time"
                    {...register("time")}
                    className="w-full px-4 py-3 rounded-xl border border-border text-text focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                  >
                    <option value="">Select a time slot</option>
                    {TIME_SLOTS.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  {errors.time && (
                    <p className="mt-1.5 text-sm text-red-500">{errors.time.message}</p>
                  )}
                </div>
              </div>
            )}

            {/* Step 3: Review */}
            {step === 2 && (
              <div className="bg-secondary rounded-xl p-6 space-y-4">
                <h3 className="text-lg font-semibold text-text">Review Your Appointment</h3>
                <div className="space-y-3">
                  {[
                    { label: "Name", value: getValues("name") },
                    { label: "Phone", value: getValues("phone") },
                    { label: "Treatment", value: getValues("treatment") },
                    { label: "Date", value: getValues("date") },
                    { label: "Time", value: getValues("time") },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between py-2 border-b border-border last:border-0">
                      <span className="text-sm text-text/60">{item.label}</span>
                      <span className="text-sm font-medium text-text">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex gap-3 pt-2">
              {step > 0 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-text border border-border rounded-xl hover:bg-secondary transition-colors"
                >
                  <ChevronLeft className="h-5 w-5" />
                  Back
                </button>
              )}
              {step < 2 && (
                <button
                  key="next-btn"
                  type="button"
                  onClick={nextStep}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-white bg-primary rounded-xl hover:bg-primary-dark transition-colors"
                >
                  Next
                  <ChevronRight className="h-5 w-5" />
                </button>
              )}
              {step === 2 && (
                <button
                  key="submit-btn"
                  type="submit"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-white bg-primary rounded-xl hover:bg-primary-dark transition-colors"
                >
                  <Calendar className="h-5 w-5" />
                  Confirm Appointment
                </button>
              )}
            </div>
          </form>
        </div>
      </section>
    </>
  );
}
