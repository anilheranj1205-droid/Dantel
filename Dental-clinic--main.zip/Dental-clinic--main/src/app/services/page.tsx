import type { Metadata } from "next";
import Link from "next/link";
import {
  Calendar,
  Sparkles,
  Shield,
  Star,
  Heart,
  Award,
  Smile,
  Crosshair,
  Scissors,
  Zap,
  CircleDot,
  Minus,
} from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { SERVICES, CLINIC_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Services",
  description: `Comprehensive dental services at ${CLINIC_NAME}: root canal, implants, teeth whitening, crowns, dentures, laser dentistry, and more.`,
};

const SERVICE_ICONS: Record<string, React.ReactNode> = {
  Zap: <Zap className="h-6 w-6" />,
  CircleDot: <CircleDot className="h-6 w-6" />,
  Sparkles: <Sparkles className="h-6 w-6" />,
  Sun: <Star className="h-6 w-6" />,
  Minus: <Minus className="h-6 w-6" />,
  Crown: <Award className="h-6 w-6" />,
  Smile: <Smile className="h-6 w-6" />,
  Crosshair: <Crosshair className="h-6 w-6" />,
  Star: <Star className="h-6 w-6" />,
  Shield: <Shield className="h-6 w-6" />,
  Scissors: <Scissors className="h-6 w-6" />,
  Heart: <Heart className="h-6 w-6" />,
};

export default function ServicesPage() {
  return (
    <>
      <section className="bg-secondary py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Our Services"
            title="Complete Dental Care Under One Roof"
            description="We offer a comprehensive range of dental treatments using modern techniques and equipment for the best results."
          />
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map((service) => (
              <div
                key={service.title}
                className="p-6 rounded-xl border border-border hover:border-primary/30 hover:shadow-sm transition-all"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                  {SERVICE_ICONS[service.icon] || <Sparkles className="h-6 w-6" />}
                </div>
                <h3 className="text-lg font-semibold text-text">{service.title}</h3>
                <p className="mt-2 text-sm text-text/60 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-primary py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white">Need a Specific Treatment?</h2>
          <p className="mt-4 text-lg text-white/80 max-w-xl mx-auto">
            Book a consultation and we will create a personalized treatment plan for you.
          </p>
          <Link
            href="/appointment"
            className="mt-8 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-medium text-primary bg-white rounded-xl hover:bg-white/90 transition-colors"
          >
            <Calendar className="h-5 w-5" />
            Book Consultation
          </Link>
        </div>
      </section>
    </>
  );
}
